package prog5121_poe;

import javax.swing.JOptionPane;
public class Task {
    
    private int totalDuration = 0;
    
    public  String getInput(String prompt){
        return JOptionPane.showInputDialog(null,prompt);
    }
    
    public int showOptions(){
        while (true){
            String input = getInput("Select an option:\n" +
                "1. Add tasks\n" +
                "2. Show report\n" +
                "3. Quit"
            );

            if (input == null){
                return 3;
            }

            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= 3) {
                    return choice; // Return valid option
                }
            } catch (NumberFormatException e) {
                // Invalid input, do nothing
            }

            JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");

            // If input is invalid, return 0
            return 0;
        }   
    }
    
    public void addTasks(){
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:"));
        int taskNumber = 0;
        
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter the name of task " + (i + 1) + ":");
            String taskDescription;
            do {
                taskDescription = JOptionPane.showInputDialog("Describe task " + (i + 1) + ":");
                if (taskDescription == null || taskDescription.length() <= 50) {
                    JOptionPane.showMessageDialog(null, "Task successfully captured");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                }
            } while (true);
            String developerDetails = JOptionPane.showInputDialog("Enter the developers full name for task " + (i + 1) + ":");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of hours task " + (i + 1) + " would take" + ":"));
            totalDuration += taskDuration;
            
            String taskID = createTaskID(taskName, taskNumber, developerDetails);
            JOptionPane.showMessageDialog(null, "Task ID: " + taskID.toUpperCase());
            
            String taskStatus;
            while (true) {
                String input = getInput("Select an option:\n" +
                    "1. To Do\n" +
                    "2. Done\n" +
                    "3. Doing"
                );

                if (input != null && !input.isEmpty()) {
                    int choice = Integer.parseInt(input);
                    if (choice == 1) {
                        taskStatus = "To Do";
                        break;
                    } else if (choice == 2) {
                        taskStatus = "Done";
                        break;
                    } else if (choice == 3) {
                        taskStatus = "Doing";
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error: You must select an option.");
                }
            }
            
            // Print task details
            String taskDetails = printTaskDetails(taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID, taskDuration);
            JOptionPane.showMessageDialog(null, taskDetails);
            
            taskNumber++; // Increment task number for the next task 
        }
        // Display total duration
        JOptionPane.showMessageDialog(null, "Total duration of all tasks: " + returnTotalHours() + " hours");
    }
    
    public boolean checkTaskDescription(String taskDescription){
        return taskDescription != null && taskDescription.length() <= 50;
    }
    
    public String createTaskID(String taskName, int taskNumber, String developerName){
        // Extracting the first two letters of the task name
        String prefix = taskName.substring(0, Math.min(taskName.length(), 2)).toUpperCase();
        // Extracting the last three letters of the developer name
        String suffix = developerName.substring(Math.max(developerName.length() - 3, 0)).toUpperCase();

        return prefix + ":" + taskNumber + ":" + suffix;
    }
    
    public String printTaskDetails(String taskStatus, String developerDetails, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration){
        return String.format(
            "Task status: %s\nDeveloper details: %s\nTask number: %d\nTask name: %s\nTask description: %s\nTask ID: %s\nDuration: %s hours",
            taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID.toUpperCase(), taskDuration
        );
    }
    
    public int returnTotalHours(){
        return totalDuration;
    }
}
